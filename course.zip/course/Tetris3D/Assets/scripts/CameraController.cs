﻿using UnityEngine;
using System;
using System.Collections;

public class CameraController : MonoBehaviour
{
    float minimumY = 1.0f;
    float maximumY  = 4.0f;
    float zoomZ = 4.0f;
    public GameObject Camera;

    // Update is called once per frame
    void Update()
    {
        float x = Input.GetAxis("Mouse X");
        float y = Input.GetAxis("Mouse Y");
        transform.rotation *= Quaternion.Euler(y, x, 0);
        transform.eulerAngles = new Vector3(transform.eulerAngles.x, transform.eulerAngles.y, 0);
    }
}
