﻿using UnityEngine;
using System.Collections;

public class WallController : MonoBehaviour {

    private void OnTriggerEnter(Collider other)
    {
        try
        {
            Destroy(other.gameObject, 5f);
            other.attachedRigidbody.useGravity = true;
            other.gameObject.transform.parent = null;
        }
        catch { }
    }

}
