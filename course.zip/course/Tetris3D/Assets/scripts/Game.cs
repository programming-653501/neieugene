﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;


public class Game : MonoBehaviour {
    public GameObject Figure1;
    public GameObject Figure2;
    public GameObject Figure3;
    public GameObject Figure4;
    public GameObject Figure5;
    public Text Score;

    public GameObject Cube1;
    public GameObject Cube2;

    public GameObject Parent;

    public GameObject[] Container;
    public GameObject[] figures;

    GameObject[] Figures = new GameObject[5];

    float timer;
    float deltatimer = 1f;

    bool GameOver = false;

    // Use this for initialization
    void Start () {
        timer = 0f;
        Figures[0] = Figure1;
        Figures[1] = Figure2;
        Figures[2] = Figure3;
        Figures[3] = Figure4;
        Figures[4] = Figure5;
    }
	
	// Update is called once per frame
	void Update () {

        figures = GameObject.FindGameObjectsWithTag("Figure");

        if (figures.Length > 0)
        {
            if (figures[0].transform.childCount == 0)
            {
                Destroy(figures[0]);
            }

            if (Input.GetKeyDown("s"))
            {
                GameObject Figure = figures[0];
                Collider[] hit;
                bool check = true;
                foreach (Transform child in Figure.transform)
                {
                    hit = Physics.OverlapSphere(new Vector3(1, 0, 0) + child.transform.position, 0.1f);
                    foreach (Collider obj in hit)
                    {
                        if (obj.gameObject.tag == "Respawn")
                        {
                            check = false;
                            break;
                        }
                    }
                }
                if (check) figures[0].transform.position += new Vector3(1, 0, 0);
            }

            if (Input.GetKeyDown("w"))
            {
                GameObject Figure = figures[0];
                Collider[] hit;
                bool check = true;
                foreach (Transform child in Figure.transform)
                {
                    hit = Physics.OverlapSphere(new Vector3(-1, 0, 0) + child.transform.position, 0.1f);
                    foreach (Collider obj in hit)
                    {
                        if (obj.gameObject.tag == "Respawn")
                        {
                            check = false;
                            break;
                        }
                    }
                }
                if (check) figures[0].transform.position += new Vector3(-1, 0, 0);
            }

            if (Input.GetKeyDown("d"))
            {
                GameObject Figure = figures[0];
                Collider[] hit;
                bool check = true;
                foreach (Transform child in Figure.transform)
                {
                    hit = Physics.OverlapSphere(new Vector3(0, 0, 1) + child.transform.position, 0.1f);
                    foreach (Collider obj in hit)
                    {
                        if (obj.gameObject.tag == "Respawn")
                        {
                            check = false;
                            break;
                        }
                    }
                }
                if (check) figures[0].transform.position += new Vector3(0, 0, 1);
            }

            if (Input.GetKeyDown("a"))
            {
                GameObject Figure = figures[0];
                Collider[] hit;
                bool check = true;
                foreach (Transform child in Figure.transform)
                {
                    hit = Physics.OverlapSphere(new Vector3(0, 0, -1) + child.transform.position, 0.1f);
                    foreach (Collider obj in hit)
                    {
                        if (obj.gameObject.tag == "Respawn")
                        {
                            check = false;
                            break;
                        }
                    }
                }
                if (check) figures[0].transform.position += new Vector3(0, 0, -1);
            }

            if (Input.GetKeyDown("q"))
            {
                figures[0].transform.Rotate(new Vector3(90, 0, 0));
            }
            if (Input.GetKeyDown("e"))
            {
                figures[0].transform.Rotate(new Vector3(-90, 0, 0));
            }

            if (Input.GetKeyDown("space"))
            {
                timer = 10f;
            }
        }
        else
        {
            if (Physics.OverlapSphere(new Vector3(5, 10, 5), 0.1f).Length > 0)
            {
                print("Game Over");
                Score.text = "Game Over";
                GameOver = true;
            }
            if (!GameOver)
            {
                Instantiate(Figures[Random.Range(0, 4)], new Vector3(5, 10, 5), Quaternion.identity, Parent.transform);
            }
        }
      
        timer += Time.deltaTime;
        if (timer >= deltatimer)
        {
            deltatimer -= 0.001f;
            if (deltatimer < 0.3f) deltatimer = 0.3f;
            Parent.transform.position += new Vector3(0, -1, 0);
            timer = 0f;
        }
	}
}
