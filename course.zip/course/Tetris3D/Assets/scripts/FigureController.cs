﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using System;

public class FigureController : MonoBehaviour {

    GameObject[] figures;
    GameObject[] text;

    private void OnTriggerEnter(Collider other)
    {
        try
        {
            if (other.tag != "Finish" && other.tag != "Wall")
            {
                GameObject Parent = transform.parent.gameObject;
                int CountChilds = Parent.transform.childCount;
                for (int i = CountChilds - 1; i >= 0; --i)
                {
                    GameObject Child = Parent.transform.GetChild(i).gameObject;
                    Child.transform.parent = null;
                    Child.transform.localScale = new Vector3(0.999f, 1, 0.999f);
                    Child.transform.rotation = Quaternion.identity;
                    Child.tag = "Respawn";
                }
                Destroy(Parent);
                tag = "Respawn";
                transform.parent = null;

                Collider[] objs;
                List<Collider> ObjList = new List<Collider>();

                for (int i = 0; i < 10; ++i)
                {
                    for (int j = 0; j < 10; ++j)
                    {
                        objs = Physics.OverlapSphere(new Vector3(i + 0.5f, 0.5f, j + 0.5f), 0.1f);
                        Debug.Log(objs.Length);
                        ObjList.AddRange(objs);
                    }
                }


                print(ObjList.Count);
                if (ObjList.Count == 100)
                {
                    foreach (Collider item in ObjList)
                    {
                        Destroy(item.gameObject);
                    }

                    text = GameObject.FindGameObjectsWithTag("Text");
                    Text t = text[0].GetComponent<Text>();
                    t.text = (Int32.Parse(t.text) + 1).ToString();

                    figures = GameObject.FindGameObjectsWithTag("Respawn");

                    foreach (GameObject obj in figures)
                    {
                        obj.transform.position += new Vector3(0, -1, 0);
                    }

                }

            }
        }
        catch { }
    }

}
